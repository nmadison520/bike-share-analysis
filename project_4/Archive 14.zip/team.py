"""Team class for Project 4."""
from participant import Participant

class Team(Participant):
    """Team class is a subclass of Participant.
    Player objects roster is held and tournament stats including wins/losses.
    """
    def __init__(self, school_name, status= "active", roster=None):
        """Initialize a Team (name, status, optional roster)."""
        self.name= school_name
        self.id=None
        self.status= status
        self.school=school_name

        if roster is None:
            self.roster=[]
        else:
            self.roster=roster
        self.tournament_stats={"wins": 0, "losses": 0}

    def __eq__(self,player2):
        """
        Team is equal only when name attributes are equal.
        """
        if isinstance(player2, Team):
            return self.name==player2.name
        return False
    
    def __str__(self):
        """Return team name and calculation (calculation= winning %)"""
        wins=self.tournament_stats.get("wins", 0)
        losses=self.tournament_stats.get("losses", 0)
        total= wins+losses
        if total==0:
            return f"{self.name}: 0.00"
        
        pct=wins/total
        return f"{self.name}: {pct:.2f}"
    
    def get_tournament_stats(self):
        """
        Return copy of tournament stats adding winning_percent.
        Keeps two decimals also.
        """
        stats_copy= self.tournament_stats.copy()
        wins= stats_copy.get("wins", 0)
        losses= stats_copy.get("losses", 0)
        total=wins+losses

        if total==0:
            wp= 0.00
        else:
            pct=wins/total
            wp=float(f"{pct:.2f}")
        
        stats_copy["winning_percent"]=wp
        return stats_copy

    def get_player(self, name, number):
        """
        Return Player in roster matching name and number, else return None.
        """
        for player in self.roster:
            if player.name== name and player.number ==number:
                return player
        return None
    
    def add_player(self, player):
        """
        Return False if player already exists (same name/number).
        Else, add to roster and return True.
        """
        if self.get_player(player.name, player.number) is not None: 
            return False
        self.roster.append(player)
        return True