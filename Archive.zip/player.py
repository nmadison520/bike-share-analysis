from participant import Participant

class Player(Participant):
    def __init__(self, name, number, school, status="healthy", position=None):
        pass

"""Player class is a subclass of Participant.
The Player constructor has the following parameters:
self, name, number, school, status="healthy", position=None
Attributes:
name : (str) representing the player name
number : (int) representing the player's jersey number
school : (str) representing the player's school
status : (str) options are healthy or injured
position : (str) players position
The __str__ method is inherited.
Define the __eq__ method so that two Player objects are equal when their name, number, and school attributes are equal.
get_tournament_stats()
Make a copy of the tournament stats attribute.
Calculate and add points per game to the copy.
Use ppg  as the dictionary key.
Points per game (ppg) is calculated by total points / total number of games.
If total number of games is zero, then the dictionary value should be 0.00.
Round to 2 decimal places.
Return the copy of the tournament stats as a dictionary. 
Note: get_tournament_stats() should not edit any attribute.
"""
