from participant import Participant

class Team():
    def __init__(self, school_name, status= "active", roster=None):
        pass

"""Team class is a subclass of Participant
The Team constructor has the following parameters:
self, school_name, status="active", roster=None
Attributes:
school_name : (str) team's school
status : (str) active, eliminated, disqualified
roster : (list) list of Player objects - initialize to empty list if None
Plus all the inherited attributes.
Add the keys wins and  loses  to self.tournament_stats, initialize them to zero.
__str__
Calculate the team's winning percentage, zero if wins + loses is zero.
Return team_name: calculation
Make sure to output the calculation with 2 decimal places.
Example)
VT Hokies: 0.50
Define the __eq__ method so that two Team objects are equal when the name attributes are equal.
get_tournament_stats()
Make a copy of the tournament_stats attribute.
Calculate the winning percentage of the team tournament stats.
Add an element to the copy, use winning_percent  as the dictionary key.
To calculate the winning percentage:  wins / number of games.
If number of games is zero, winning percentage is 0.00.
Round to 2 decimal places.
Return the copy of the tournament stats as a dictionary. 
Note: get_tournament_stats() should not change any attribute.
get_player()
Has the following parameters: self, name, number
name: (str) Player's name
number: (int) Player's jersey number
If the player exists in the team, return the player, otherwise return None.
add_player()
Has the following parameters: self, player
player: (Player) Player object to add to the roster
If the player does not exist in the team, add the player to the team's roster, and return True.
If the player already exists, do not add the player, and return False.
"""