
package example;

/**
 * Represents a server computer that can manage multiple single-board 
 * computers (SBCs).
 * 
 * This class extends the abstract Computer class and provides functionality 
 * to start and shut down the server along with its associated SBCs.
 * 
 * @author hillman
 * @version 2025.12.03 yyyy.mm.dd
 */
public class Server extends Computer {

    //~ Fields ................................................................
    private SingleBoard[] sbcs;
    
    //~ Constructors ..........................................................

    /**
     * Constructs a new Server instance.
     *
     * @param name     the name of the server
     * @param ramSize  the amount of RAM in megabytes
     */
    public Server(String name, int ramSize) {
        super(name, ramSize);
        sbcs = new SingleBoard[5];
    }
    
    //~ Public Methods ........................................................

    /**
     * Attempts to add a new single-board computer to the server.
     * 
     * The SBC will be added to the first available slot in the sbcs array.
     * If the array is full, the method returns false.
     *
     * @param newBoard the SingleBoard computer to add
     * @return true if the SBC was successfully added; false otherwise
     */
    public boolean addSBC(SingleBoard newBoard) {
        for (int i = 0; i < sbcs.length; i++) {
            if (sbcs[i] == null) {
                sbcs[i] = newBoard;
                return true;
            }
        }
        return false; // No available slot
    }

    /**
     * Starts the server and all associated SBCs.
     * Prints a message for the server and each SBC.
     */
    @Override
    public void start() {
        System.out.println("starting the server:");
        for (int i = 0; i < sbcs.length; i++) {
            if (sbcs[i] != null) {
                sbcs[i].start();
            }
        }
    }

    /**
     * Shuts down the server and all associated SBCs.
     * Prints a message for the server and each SBC.
     */
    @Override
    public void shutdown() {
        System.out.println("shutting down the server:");
        for (SingleBoard sbc : sbcs) {
            if (sbc != null) {
                sbc.shutdown();
            }
        }
    }
}
