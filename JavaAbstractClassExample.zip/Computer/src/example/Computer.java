package example;

// -------------------------------------------------------------------------

/**
 * An abstract class representing a generic Computer.
 *
 * This example is designed for the second day of classwork on abstract classes.
 * In this model:
 * - Computer serves as the abstract base class.
 * - SingleBoard and Server are concrete subclasses of Computer.
 * - Additionally, Server includes a SingleBoard instance as one of its fields.
 * 
 *  @author hillman
 *  @version 2025.12.03 yyyy.mm.dd
 */
public abstract class Computer {
 // Common attributes for all computers
 private String brand;
 private int ramSize; // in GB

 // ----------------------------------------------------------
/**
 * Create a new Computer object.
 * @param brand (String) representing computer brand
 * @param ramSize (int) representing RAM in GB
 */
 public Computer(String brand, int ramSize) {
     this.brand = brand;
     this.ramSize = ramSize;
 }

/**
 * Abstract method: must be implemented by subclasses
 */
 public abstract void start();

/**
 * Abstract method: must be implemented by subclasses
 */
public abstract void shutdown();

//Concrete methods: shared by all subclasses
/**
 * Print the field values to the screen
 */
 public void displaySpecs() {
     System.out.println("Brand: " + brand);
     System.out.println("RAM: " + ramSize + " GB");
 }

 // ----------------------------------------------------------
/**
 * Place a description of your method here.
 * @return (String) repesenting the computer brand
 */
 public String getBrand() {
     return brand;
 }

/**
 * Getter Method for ramSize
 * @return (int) representing RAM in GB
 */
 public int getRamSize() {
     return ramSize;
 }
 
/**
 * Setter for ramSize
 * @param newRam (int) representing the computers RAM in GB
 */
public void setRamSize(int newRam) {
     ramSize = newRam;
 }

}
