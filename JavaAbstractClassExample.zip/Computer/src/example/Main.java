
package example;

/**
 * The entry point for this demonstration program.
 *
 * Note for CS2114 projects:
 * While this example uses a class named Main with a main method,
 * projects in CS2114 typically run applications from classes that are NOT
 * named Main. This process is handled "behind the scenes" by the course
 * infrastructure. Students should focus on designing classes and methods rather
 * than worrying about the entry point.
 *
 * This example demonstrates:
 * - Encapsulation: 
 *    Fields like brand and ramSize are private
 *    and accessed through constructors and methods, not directly.
 * - Inheritance: 
 *    Server and SingleBoard extend the abstract Computer class.
 * - Immutability of brand: 
 *     The brand field has no setter, so it cannot be changed after 
 *     construction.
 *     
 * @author hillman
 * @version 2025.12.03 yyyy.mm.dd
 */
public class Main {

    /**
     * Demonstrates creating a Server, adding SingleBoard computers,
     * and starting/shutting down the system.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        // Create a Server instance (brand cannot be changed later)
        Server cs2064 = new Server("Lenovo", 128);

        // Create SingleBoard computers
        SingleBoard pi1 = new SingleBoard("Raspberry Pi 1", "Raspberry", 4);
        SingleBoard pi2 = new SingleBoard("Raspberry Pi 2", "Raspberry", 8);

        // Add SBCs to the server
        boolean added1 = cs2064.addSBC(pi1);
        boolean added2 = cs2064.addSBC(pi2);

        System.out.println("Added Pi 1: " + added1);
        System.out.println("Added Pi 2: " + added2);

        // Start the server and its SBCs
        cs2064.start();

        // Shut down the server and its SBCs
        cs2064.shutdown();

        // Demonstrate encapsulation: brand cannot be changed (no setter)
        // cs2064.setBrand("NewBrand"); // This would be invalid
        
        // Demonstrate encapsulation: we can add to sbcs but we cannot remove
        // from sbcs, nor do we have direct access to the individual sbc(s) as
        // there are no getters and setters for sbcs. For practice, write 
        // the getter, setter, remove methods for sbcs and practice editing
        // the sbcs instance variable. 
    }
}
