
package example;

/**
 * Represents a single-board computer, such as a Raspberry Pi.
 * 
 * This class extends the abstract Computer class and provides
 * specific implementations for starting and shutting down a single-board 
 * device.
 * 
 * @author hillman
 * @version 2025.12.03 yyyy.mm.dd
 */
public class SingleBoard extends Computer {

    //~ Fields ................................................................
    
    private String name;
    
    //~ Constructors ..........................................................

    /**
     * Constructs a new SingleBoard instance.
     *
     * @param name  the name of the single-board computer
     * @param brand the brand of the computer
     * @param ram   the amount of RAM in megabytes
     */
    public SingleBoard(String name, String brand, int ram) {
        super(brand, ram);
        this.name = name;
    }

    /**
     * Starts the single-board computer.
     * Prints a message indicating a slow startup.
     */
    @Override
    public void start() {
        System.out.println("starting " + name + " ... slowly");
    }

    /**
     * Shuts down the single-board computer.
     * Prints a message indicating the computer is tired.
     */
    @Override
    public void shutdown() {
        System.out.println("shutting down " + name + " ... I'm tired.");
    }
}
